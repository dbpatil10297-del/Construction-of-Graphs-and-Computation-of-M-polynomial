# Idempotent Graph Computational Verification App

This Streamlit application uses the supplied Python graph-construction and M-polynomial logic.

## Run locally
1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Run: `pip install -r requirements.txt`
4. Run: `streamlit run app.py`

## Public deployment
1. Upload `app.py` and `requirements.txt` to a GitHub repository.
2. In Streamlit Community Cloud, create an app from that repository and select `app.py`.
3. After deployment, test the public URL in a private/incognito browser window.
4. Add that verified URL to the thesis.

The app currently limits n to 100 as a responsiveness safeguard. Raise or lower the limit only after testing performance for the graph and its line graph.
